import React from "react";
import "../Component_Styles/navbar.css";

export default function Navbar2()
{
    return (

        <header className="navigBar">
            <a href="/" className="navig-brand">
               <span>Esports</span>
            </a>
        </header>
    );
}